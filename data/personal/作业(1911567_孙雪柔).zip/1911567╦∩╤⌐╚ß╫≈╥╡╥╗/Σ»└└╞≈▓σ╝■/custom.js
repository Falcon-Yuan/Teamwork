console.log(document.title);
document.querySelector('aside').innerHTML=''
document.querySelector('.recommend-right_aside').innerHTML=''
document.querySelector('main').style.width ='100%'
document.getElementById('rightAside').parentNode.removeChild(document.getElementById('rightAside'))
